var searchData=
[
  ['namespaces',['Namespaces',['../doc_global_namespace.html',1,'doc_script_global']]]
];
