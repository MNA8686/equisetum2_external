var searchData=
[
  ['objects_20and_20handles',['Objects and handles',['../doc_datatypes_obj.html',1,'doc_builtin_types']]],
  ['object_20handles_20to_20the_20application',['Object handles to the application',['../doc_obj_handle.html',1,'doc_understanding_as']]],
  ['operator_20precedence',['Operator precedence',['../doc_operator_precedence.html',1,'doc_script']]],
  ['overview',['Overview',['../doc_overview.html',1,'doc_start']]],
  ['operator_20overloads',['Operator overloads',['../doc_script_class_ops.html',1,'doc_script_class']]],
  ['object_20handles',['Object handles',['../doc_script_handle.html',1,'doc_script']]]
];
