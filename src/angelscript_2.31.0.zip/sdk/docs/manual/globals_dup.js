var globals_dup =
[
    [ "a", "globals.html", null ]
];