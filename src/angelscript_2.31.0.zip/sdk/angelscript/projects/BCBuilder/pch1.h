/*
  Diese vorcompilierte Header-Include-Datei wurde am 12.06.2010 17:09:47 vom 
  RAD Studio-Experten f�r vorcompilierte Header mit den folgenden Einstellungen
  erzeugt:

  Projekt: E:\Eigene Dateien\RAD Studio\Projekte\repository\3rdparty\AngelScript\svn\angelscript\projects\BCBuilder\AngelScriptBCC_Static.cbproj
  AllowUnguarded = -1
  ExcludeProjectFiles = -1
  IncludePathsOn = -1
  IncludePaths = 
  ExcludePaths = 
  IncludeCount = 5
  ManageHeader = -1
*/

#ifndef pch1_H
#define pch1_H
#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <new>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <string>
#include <stdarg.h>
#endif
