If you haven't done that already set up an environment variable named MINGDIR
pointing the the directory where your MinGW is, e.g. "C:\MINGW"

To compile the library, just type in the command line:

make
make install

Sent in by Jakub "krajzega" Wasilewski